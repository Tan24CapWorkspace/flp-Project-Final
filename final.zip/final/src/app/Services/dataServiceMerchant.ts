import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Product } from "../models/product";
import { Merchant } from "../models/merchant";




@Injectable({
    providedIn:'root'
})
 export class dataService{
     constructor(private http:HttpClient){}
     
     addProduct(product){
         this.http.post(`http://localhost:5000/product/add`,product);
     }

     deleteProduct(product){
        this.http.delete(`http://localhost:5000/product/delete`,product);
    }

    fetchInventory(mid){
        return this.http.get<Product[]>(`http://localhost:5000/inventoryControl/`+mid);
    }

    fetchMerchantDetails(mid){
        return this.http.get<Merchant>(`http://localhost:5000/merchantprofile/`+mid);
    }

 }