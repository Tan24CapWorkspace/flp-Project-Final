import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import {Observable} from 'rxjs';
import {Product} from '../models/Product';
import {Response} from "../models/response"
//import { identifierModuleUrl } from "@angular/compiler";

let baseUrl = "http://localhost:5000/products";

@Injectable({
    providedIn:'root'
})

export class ProductSingleService{
    constructor(private http:HttpClient){}
    //id: number=8;

    

    getproduct()
    {       
          return this.http.get<Product[]>(baseUrl+"/get");
    }
    findproduct(pid: string){
        let options = { "headers": 
        new HttpHeaders({"Content-Type": "application/json" }) };
        return this.http.get<Product>(baseUrl+"/"+pid,options);

    }
  
    addWishList(pid:any,uid:any){
       let object={
            "userId":uid,
            "productId":pid
            }
     console.log(`${baseUrl}`+`/new`);
     
            return this.http.post(baseUrl +"/newwishlist",object );
          
    }
    displayWishlist(uid:any):Observable<any>{
        let object={
            "userId":uid
         }
        return this.http.post<Product>(baseUrl +"/getWishlist",object);
    }
    deleteFromWishlist(pid:any,uid:any){
        //console.log("delete"+productId);
        
        let object={
            "userId":uid,
            "productId":pid
            }
            return this.http.post(baseUrl +"/remove",object).subscribe(data=>{console.log(data)});
    }

    addCart(pid:any,uid:any){        
        let object1={
            "userId":uid,
            "productId":pid
            }     
            return this.http.post(baseUrl +"/NewCart",object1 );
            }

    displayCart(uid:any):Observable<any>{
        let object={
            "userId":uid
         }
        return this.http.post<Product>(baseUrl +"/getCart",object);
    }
    deleteFromCart(pid:any,uid:any){
       // console.log("deleteCart"+productId);
        
        let object={
            "userId":uid,
            "productId":pid
            }
            return this.http.post(baseUrl +"/removeCart",object).subscribe(data=>{console.log(data)});
    }

    
placeorder(order:any):Observable<Response>{

    var userid = sessionStorage.getItem('user');
    console.log(userid)
    console.log(order);
    return this.http.get<Response>("http://localhost:5000/placeorder/placingorder/"+userid);

}
 

getsimilarProduct(category: string, subcategory: string, productId: number): Observable<Product[]>{
    return this.http.get<Product[]>("http://localhost:5000/similar?category="+category+"&subcategory="+subcategory+"&productId="+productId);
}    



deleteCart(){
    let object={
        "userId":sessionStorage.getItem("user")
        }
    return this.http.post(baseUrl+"/deleteCart", object);
}


}