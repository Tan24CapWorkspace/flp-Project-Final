import {Injectable} from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';

import {Transaction} from '../models/Transaction.model'
import { productReturn } from '../models/return.model';
import { Observable } from 'rxjs';


const httpOptions={
    headers: new HttpHeaders({ 'Content-Type' : 'application/json'})
};

@Injectable({
    providedIn:'root'
})
export class TransactionService{
    constructor(private http:HttpClient){}

    private userUrl='http://localhost:5000/orders';



    public getTransactionDetailsByTrId(TransactionId):Observable<productReturn> {
        
        return this.http.get<productReturn>(this.userUrl + "/myorders/"+TransactionId);
    }
    public getTranactions(userId):Observable<any>{
        return this.http.get<number[]>(this.userUrl+"/myorders/userid/"+userId)

    }

    

   



}
