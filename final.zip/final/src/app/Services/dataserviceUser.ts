import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import {HttpHeaders} from '@angular/common/http'
//import { wishlist } from "./wishlist.component";
import { User } from "../models/User";

let baseUrl = "http://localhost:5000/";

@Injectable({
    providedIn:'root'
})
export class DataService{
    constructor(private http:HttpClient){}

        // getWishList(userId)
        // {
        //     this.http.get<wishlist>(`baseUrl+"/wishlist/${userId}"`)
        // }
        update(user1)
        {
            return this.http.put(baseUrl+"customer/update",user1);
        }
        
    display(userId)
    {
        return this.http.get<User>(baseUrl+"customer/"+userId);
    }

    }


