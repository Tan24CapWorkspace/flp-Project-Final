import {AdminService} from '../../services/app.adminService';
import { Component } from '@angular/core';
import { Router } from '@angular/router';
import {User, User1} from '../../models/User';
import { CapStoreSearchService } from 'src/app/Services/app.CapStoreSearchService';
import { Product } from 'src/app/models/product';

@Component({
    // tslint:disable-next-line: component-selector
    selector: 'show-user',
    templateUrl: 'showUser.html'
})

export class ShowUserComponent {
    constructor(private service: AdminService, private route:Router, private searchService: CapStoreSearchService) {}
    user: User[] = [];
    userId:number;
    // tslint:disable-next-line: use-life-cycle-interface
    ngOnInit(): void {
        this.service.getUser().subscribe(
            res => {
               this.user = res;

            },
            err => {
                alert('an error has occurred');
            }
        );
        this.userId = 0;
       }

       deleteUser(data: number): any {
        this.userId =  this.user[data].userId;
       if (this.service.deleteUser(this.userId).subscribe( data => {console.log(data);
       },
       error => console.log(error)

       ))
       {
         if (confirm('Are you Sure You Want To Delete')) {
           this.user.splice(data, 1);
         }
       }
      }

      backtoadmin()
      {
        this.route.navigate(['admin']);

      }


      value:string;
      user1: User1;

      // findProduct() {
      //  console.log(this.value)

      //   if(this.value===""){
      //     this.service.getUser().subscribe(
      //       res => {
      //          this.user = res;

      //       },
      //       err => {
      //           alert('an error has occurred');
      //       }
      //   );
      //   this.userId = 0;
      // }
      // else{
      //   this.searchService.findUser(this.value).subscribe(
      //     res=>{
      //       if(res === null){
      //         alert("no product found")
      //       }else{
      //          this.user.splice(0,this.user.length);
      //          this.user1 = res;
      //          this.user.push(this.user1)
      //       }
            
      //     }
      //   )
      // }
        
    
    
}
