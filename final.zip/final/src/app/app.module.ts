﻿import { NgModule, Component } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Showcomponent } from './ShowFeature/show.component';
import { ProductService } from './Services/productService';
import { LoginComponent } from './login/login.component';
import { Admin } from './component/admin/admin.component';
import { MerchComponent } from './merch/merch.component';
import { Customer } from './customer/customer.component';
import { PasswordComponent } from './component/passwordComponent/getPasword';
import { SignUpComponent } from './component/signupComponent/app.signup';
import { ChangePasswordComponent } from './component/passcomponent/password';
import { LogoutComponent } from './logout/logout.component';
import { ShowUserComponent } from './component/showUser/showUser';
import { AddProductClass } from './component/addproduct/addProduct';
import {AddProductClass1 } from './component/addproductMerchant/addProduct';
import { GetAllMerchantComponent } from './component/showMerchant/app.getAllMerchant';
import { ShowProductComponent } from './component/showProduct/showProduct';
import { ShowDiscountComponent } from './component/showDiscount/showDiscount';
import { AddDiscountComponent } from './component/addDiscount/addDiscount';
import { ShowPromocodeComponent } from './component/showPromocode/showPromocode';
import { AddMerchantComponent } from './component/AddMerchant/app.addMerchant';
import { AddPromoComponent } from './component/addPromocode/addPromocode';
import { ManageTPMerchant } from './component/showTPMerchant/tpMerchant';
import { ShowWishlist } from './wishlist/app.wishlist';
import { ShowCart } from './cart/app.cart';
import { ShowProductSingleComponent } from './showSingleProduct/app.showSingleProduct';
import{FileUploadModule} from 'ng2-file-upload'
import { adminSearchComponent } from './SearchFeature/app.adminSearch';
import { merchantSearchComponent } from './SearchFeature/app.merchantSearch';
import { User1SearchComponent } from './SearchFeature/app.user1Search';
import { ShippingComponent } from './component/shippingAddress/shipping.component';
import { PaymentComponent } from './component/payment/payment';

import { showInvoice } from './component/InvoiceGeneration/showInvoice';
import { FindTransactionComponent } from './component/return/app.findTransaction';
import { AppratingComponent } from './component/RatingandReview/app.ran';
import { MerchantProfileComponent } from './component/Merchant/profile-merchant';
import { MerchantComponent } from './component/Merchant/merchant';
import { InventoryControlComponent } from './component/Merchant/inventory.component';
import { UpdateCustomerComponent } from './component/userupdate/update_customer';
import { CustomerComponent } from './component/userupdate/customer';



const routes: Routes = [
    { path: 'home', component: Showcomponent },
    { path: 'login', component: LoginComponent },
    { path: 'admin', component: Admin },
    { path: 'merchant', component: MerchantComponent },
    { path: 'customer', component: Showcomponent },
    { path: 'forgotpassword', component: PasswordComponent },
    { path: 'registration', component: SignUpComponent },
    { path: 'changepassword', component: ChangePasswordComponent },
    { path: 'logout', component: LogoutComponent },
    { path: '', redirectTo: 'home', pathMatch: 'full' },
    { path: 'showUser', component: ShowUserComponent },
    { path: 'showMerchant', component: GetAllMerchantComponent },
    { path: 'addProduct', component: AddProductClass },
    { path: 'showProduct', component: ShowProductComponent },
    { path: 'showDiscount', component: ShowDiscountComponent },
    { path: 'addDiscount', component: AddDiscountComponent },
    { path: 'showPromocode', component: ShowPromocodeComponent },
    { path: 'addMerchant', component: AddMerchantComponent },
    { path: 'addPromocode', component: AddPromoComponent },
    { path: 'showTPMerchant', component: ManageTPMerchant },
    { path: 'showSingleProduct', component: ShowProductSingleComponent },
    { path: 'showCart', component: ShowCart },
    { path: 'showWishlist', component: ShowWishlist },
    { path: 'shipping',component:ShippingComponent},
    { path: 'payment', component: PaymentComponent},
    { path: 'invoice',component:showInvoice},
    { path: 'return',component:FindTransactionComponent},
    { path: 'rating',component:AppratingComponent},
    { path: 'profile',component:MerchantProfileComponent},
    { path: 'merinventory',component:InventoryControlComponent},
    {path:'update',component:UpdateCustomerComponent},
    {path:'customerprofile',component:CustomerComponent},
    
    // {path:'registration', component: SignUpComponent}
    {path:'addProductMerchant',component:AddProductClass1},
]


@NgModule({
    imports: [
        BrowserModule,
        FormsModule,
        RouterModule.forRoot(routes),
        HttpClientModule,FileUploadModule,
        ReactiveFormsModule
    ],
    declarations: [
        AppComponent,
        Showcomponent,
        LoginComponent,
        Customer,
        MerchComponent,
        PasswordComponent,
        SignUpComponent,
        ChangePasswordComponent,
        ShowWishlist,
        ShowCart,
        ShowProductSingleComponent,
        LogoutComponent,
        merchantSearchComponent,
        User1SearchComponent,
        ShowUserComponent,
        ManageTPMerchant,
        AddProductClass,
        GetAllMerchantComponent,
        AddPromoComponent,
        ShowProductComponent,
        ShowDiscountComponent, 
        AddDiscountComponent, 
        ShowPromocodeComponent, 
        AddMerchantComponent, 
        Admin,AddProductClass1,
        ShippingComponent,
        PaymentComponent,
        showInvoice,
        FindTransactionComponent,
        AppratingComponent,
        MerchantProfileComponent,
        MerchantComponent,
        InventoryControlComponent,
        UpdateCustomerComponent,
        CustomerComponent
        //      SignUpComponent
    ],
    providers: [ProductService],
    bootstrap: [AppComponent]
}) 

export class AppModule {

}