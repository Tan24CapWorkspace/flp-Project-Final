import { Component,OnInit} from "@angular/core";
import {ProductSingleService} from '../Services/showSingleProductService';
import {Product} from '../models/Product';
import {Observable} from 'rxjs';
import { PathLocationStrategy } from "@angular/common";
import { Router } from "@angular/router";
@Component({
    selector:'show-cart',
    templateUrl:'app.cart.html'
})

export class ShowCart implements OnInit{

    str3:string
    constructor(private service:ProductSingleService,private router:Router){
        this.str3 = sessionStorage.getItem('user')
    if(this.str3 == null){
      this.router.navigate(['home'])
    }
    }
    products:Product[]=[];
    quantity:number=1;
    product:Product;
    
    pid: string;
    uid: string;
    
    ngOnInit(): void {
        this.pid = sessionStorage.getItem('productId')
        this.uid = sessionStorage.getItem("user") 
       this.service.displayCart(this.uid).subscribe(data=>this.products=data);     
    }

    removeFromCart(index:number){
        let productId = this.products[index].productID
        this.service.deleteFromCart(productId,this.uid)
        window.location.reload();
    }
    placeOrder(){

         if(this.products.length === 0)
         {
              alert("Your cart is empty")
            }
          else{
            let amount:any=0;
            for(let amt of this.products){
                amount=amount+amt.price;
                }
                console.log(amount);
                
                if(amount>1000){
                    let  order:number[]=[]
                    for(let data of this.products){
                        order.push(data.productID)
                    }
                   
                    this.service.placeorder(order).subscribe(
                        res=>{
                            if(res.status == 200){
                                console.log("placing order")
                                this.router.navigate(['shipping'])
                            }else{
                                alert(res.message)
                            }
                        }
                    )
    
                    }else{
                    alert("Cart value should be more then 10000");
                    console.log("hello");   
                }
            }
                    }
        
   }
