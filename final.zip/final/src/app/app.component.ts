﻿import { Component, OnInit } from '@angular/core';
import { AuthenticationService } from './Services/authentication.service';
import { Router } from '@angular/router';

@Component({
    selector: 'app',
    templateUrl: 'app.component.html'
})
export class AppComponent implements OnInit {
    
    loggedIn:boolean = false;

    ngOnInit(): void {
    }
    constructor(private service:AuthenticationService, private router: Router){
      
    }

    loggin():boolean{

        if (sessionStorage.length != 0) {
            //alert("login")
            return true
          }
          else {
            //alert("logout")
            return false
          }
    }

    checkWishlist() {
      if (sessionStorage.length == 0) {
          alert("Please Login First")
          this.router.navigate(['home'])
      }
      else {
            this.router.navigate(['showWishlist'])
      }
  }
  checkOrder() {
      if (sessionStorage.length == 0) {
          alert("Cant display Order!")
          this.router.navigate(['home'])
      }
      else {
         
      }
  }
  checkReturn() {
      if (sessionStorage.length == 0) {
          alert("Cant display Return!")
          this.router.navigate(['home'])
      }
      else {
        alert("user")
        this.router.navigate(['return'])
      }
  }
  checkCart() {
      if (sessionStorage.length == 0) {
        alert("Please Login First")
          this.router.navigate(['home'])
      }
      else {
         this.router.navigate(['showCart'])
      }
  }



    
}