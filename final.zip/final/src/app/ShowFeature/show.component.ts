import { Component } from "@angular/core";
import { ProductService } from "../Services/productService";
import { Product } from "../models/product";
import { Sorting } from "../models/sorting";
import { AuthenticationService } from "../Services/authentication.service";
import { Router } from "@angular/router";
import { ProductSingleService } from "../Services/showSingleProductService";
import { CapStoreSearchService } from "../Services/app.CapStoreSearchService";

@Component({
    selector: "show",
    templateUrl: "show.component.html"
})
export class Showcomponent {

    search: string
    value: string =""
    str2:string

    constructor(private searchService: CapStoreSearchService, private service: ProductService, private service1: AuthenticationService, private router: Router, private singleproductservice: ProductSingleService) {
        this.getProducts();
        this.search="name";

        this.str2 = sessionStorage.getItem('admin')
    //alert(this.str2)
    if(this.str2 != null){
      this.router.navigate(['admin'])
    }
    }


    products: Product[] = [];

    inputFormat: Sorting = {
        category: '',
        sortingType: ''
    }

    getProducts() {
        this.service.getProducts().subscribe(
            res => {
                console.log("here")
                this.products = res;
                for(let data of this.products){
                    data.photo="http://127.0.0.1:8887"+data.photo.substring(25)
                }
            }
        )
    }

    showProduct(i) {
        let productId = this.products[i].productID
        sessionStorage.setItem('productId', "" + productId)
        //let a = sessionStorage.getItem('productId')
        this.router.navigate(['showSingleProduct'])

    }

    sortProducts() {
        if (this.inputFormat.sortingType === "low_to_high")
            this.service.sortAsc(this.inputFormat).subscribe(
                res => {
                    this.products = res
                    for(let data of this.products){
                        data.photo="http://127.0.0.1:8887"+data.photo.substring(25)
                    }
                    console.log(res)
                }
            )

        if (this.inputFormat.sortingType === "high_to_low")
            this.service.sortDesc(this.inputFormat).subscribe(
                res => {
                    this.products = res
                    for(let data of this.products){
                        data.photo="http://127.0.0.1:8887"+data.photo.substring(25)
                    }
                    console.log(res)
                }
            )

        if (this.inputFormat.sortingType === "best_seller")
            this.service.sortBestSeller(this.inputFormat).subscribe(
                res => {
                    this.products = res
                    for(let data of this.products){
                        data.photo="http://127.0.0.1:8887"+data.photo.substring(25)
                    }
                    console.log(res)
                }
            )
    }


    findProduct(){
        // if(this.value===""){
        //     window.location.reload()
        // }


        if (this.search === "name"){
            if(this.value===""){
               this.getProducts()
            }
            this.searchService.findbyProductName(this.value).subscribe(
                res => {
                    this.products = res;
                    for(let data of this.products){
                        data.photo="http://127.0.0.1:8887"+data.photo.substring(25)
                    }
                    console.log(res)
                },
                err => {
                    
                }
            )
        }
         if (this.search === "company"){
            if(this.value===""){
                this.getProducts()
             }
            this.searchService.findbyCompanyName(this.value).subscribe(
                res => {
                    this.products = res;
                    for(let data of this.products){
                        data.photo="http://127.0.0.1:8887"+data.photo.substring(25)
                    }
                    console.log(res)
                },
                err => {
                  
                }
            )}

    }

}

