export class Response{
    status: number;
    message: string;
    object: any;
}