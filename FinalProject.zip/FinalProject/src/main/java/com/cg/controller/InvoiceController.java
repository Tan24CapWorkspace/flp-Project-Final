package com.cg.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.model.InvoiceProductModel;
import com.cg.service.InvoiceService;

@RequestMapping("/invoice")
@CrossOrigin("*")
@RestController
public class InvoiceController {

	@Autowired
	private InvoiceService invoiceService;

	@GetMapping("/get/{orderid}")
	public InvoiceProductModel getAll(@PathVariable int orderid) {
		return invoiceService.showInvoice(orderid);
	}

}
